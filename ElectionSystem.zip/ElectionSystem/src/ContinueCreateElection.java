import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.border.EmptyBorder;
import java.awt.Toolkit;
import javax.swing.border.TitledBorder;
import javax.swing.JTextField;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.DefaultComboBoxModel;
import javax.swing.DefaultListModel;
import javax.swing.JTextPane;
import java.awt.Color;
import javax.swing.JSpinner;
import javax.swing.SpinnerNumberModel;
import javax.swing.Timer;
import javax.swing.JToggleButton;
import java.awt.ScrollPane;
import java.awt.List;
import javax.swing.JList;
import javax.swing.JOptionPane;
import javax.swing.ScrollPaneConstants;
import javax.swing.JButton;
import java.awt.Button;
import java.awt.event.ActionListener;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.awt.event.ActionEvent;
import java.awt.Font;
import javax.swing.JTextArea;

public class ContinueCreateElection extends JFrame {

	private JPanel contentPane;
	private JTextField txtElectionname;
	private JTextField textFieldBallotDet;
	private JButton btnFinish;
	private JList list;
	private JSpinner spinnerTimes, spinnerDays, spinnerHour, spinnerMinutes, spinnerSeconds; //how many times can they vote spinner && Date spinners
	private JComboBox comboBoxVote; //Text box for account type voting in the election

	/**
	 * Create the frame.
	 */
	public ContinueCreateElection() {
		setResizable(false);
		setTitle("Create Election Details");
		setIconImage(Toolkit.getDefaultToolkit().getImage(ContinueCreateElection.class.getResource("/images/Deku_Link_Artwork.png")));
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 620, 500);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setBorder(new TitledBorder(null, "Election Details", TitledBorder.LEADING, TitledBorder.TOP, null, null));
		panel.setBounds(12, 13, 298, 327);
		contentPane.add(panel);
		panel.setLayout(null);
		
		txtElectionname = new JTextField();
		txtElectionname.setEditable(false);
		txtElectionname.setText("ElectionName");
		txtElectionname.setBounds(12, 39, 207, 22);
		panel.add(txtElectionname);
		txtElectionname.setColumns(10);
		
		JLabel lblElectionType = new JLabel("Election Type");
		lblElectionType.setBounds(12, 74, 88, 16);
		panel.add(lblElectionType);
		
		JComboBox comboBoxType = new JComboBox();
		comboBoxType.setModel(new DefaultComboBoxModel(new String[] {"Single Ballot", "Multiple Ballot"}));
		comboBoxType.setBounds(12, 91, 207, 22);
		panel.add(comboBoxType);
		
		JLabel lblWhoCanVote = new JLabel("Who can Vote?");
		lblWhoCanVote.setBounds(12, 126, 88, 16);
		panel.add(lblWhoCanVote);
		
		comboBoxVote = new JComboBox();
		comboBoxVote.setModel(new DefaultComboBoxModel(new String[] {"Full Time Students", "All Students", "College Specific", "Class Rank Specific"}));
		comboBoxVote.setBounds(12, 142, 207, 22);
		panel.add(comboBoxVote);
		
		JLabel lblHowManyTimes = new JLabel("How Many Times Can they Vote:");
		lblHowManyTimes.setBounds(12, 170, 187, 16);
		panel.add(lblHowManyTimes);
		
		spinnerTimes = new JSpinner();
		spinnerTimes.setEnabled(false);
		spinnerTimes.setModel(new SpinnerNumberModel(1, 1, 99, 1));
		spinnerTimes.setBounds(12, 199, 42, 22);
		
		
		panel.add(spinnerTimes);
		
		JTextPane textPaneWho = new JTextPane();
		textPaneWho.setEditable(false);
		textPaneWho.setFont(new Font("Tahoma", Font.PLAIN, 13));
		textPaneWho.setBackground(Color.PINK);
		textPaneWho.setText("You've Selected . Who in the can vote? ***Make sure your input matches a valid account type/attribute***");
		textPaneWho.setBounds(12, 222, 274, 68);
		panel.add(textPaneWho);
		
		textFieldBallotDet = new JTextField();
		textFieldBallotDet.setBounds(12, 292, 207, 22);
		panel.add(textFieldBallotDet);
		textFieldBallotDet.setColumns(10);
		
		Timer timerBallotType = new Timer(10, new ActionListener(){
			@Override
			public void actionPerformed(ActionEvent arg0) {
				if(comboBoxType.getModel().getSelectedItem().equals("Single Ballot"))
				{
					spinnerTimes.setValue(1);
					spinnerTimes.setEnabled(false);
				}
				else
				{
					spinnerTimes.setEnabled(true);
				}
				if(comboBoxVote.getModel().getSelectedItem().equals("Full Time Students") || comboBoxVote.getModel().getSelectedItem().equals("All Students"))
				{
					textPaneWho.setText("You've Selected " + comboBoxVote.getModel().getSelectedItem());
					textFieldBallotDet.setEnabled(false);
				}
				else
				{
					textPaneWho.setText("You've Selected " + comboBoxVote.getModel().getSelectedItem() + ". Who in the " + comboBoxVote.getModel().getSelectedItem() + " can vote? ***Make sure your input matches a valid account type/attribute***");
					textFieldBallotDet.setEnabled(true);
				}
				
			}
			
		});
		timerBallotType.start();
		
		
		JPanel panel_1 = new JPanel();
		panel_1.setBorder(new TitledBorder(null, "Election Length", TitledBorder.LEADING, TitledBorder.TOP, null, null));
		panel_1.setBounds(322, 13, 268, 207);
		contentPane.add(panel_1);
		panel_1.setLayout(null);
		
		JTextPane txtpnYourElectionWill = new JTextPane();
		txtpnYourElectionWill.setBounds(12, 148, 244, 48);
		panel_1.add(txtpnYourElectionWill);
		txtpnYourElectionWill.setBackground(Color.ORANGE);
		txtpnYourElectionWill.setForeground(Color.BLACK);
		txtpnYourElectionWill.setEditable(false);
		txtpnYourElectionWill.setText("If you create the election now, Your election will end on: , at");
		
		JLabel lblLengthOfElection = new JLabel("Length of the Election (in days)");
		lblLengthOfElection.setBounds(12, 27, 183, 16);
		panel_1.add(lblLengthOfElection);
		
		spinnerDays = new JSpinner();
		spinnerDays.setBounds(12, 56, 42, 22);
		panel_1.add(spinnerDays);
		
		JLabel lblHours = new JLabel("Hours");
		lblHours.setBounds(12, 91, 42, 16);
		panel_1.add(lblHours);
		
		spinnerHour = new JSpinner();
		spinnerHour.setBounds(12, 113, 42, 22);
		panel_1.add(spinnerHour);
		spinnerHour.setModel(new SpinnerNumberModel(0, 0, 23, 1));
		
		JLabel lblMinutes = new JLabel("Minutes");
		lblMinutes.setBounds(82, 91, 54, 16);
		panel_1.add(lblMinutes);
		
		spinnerMinutes = new JSpinner();
		spinnerMinutes.setBounds(82, 113, 42, 22);
		panel_1.add(spinnerMinutes);
		spinnerMinutes.setModel(new SpinnerNumberModel(0, 0, 59, 1));
		
		JLabel lblSeconds = new JLabel("Seconds");
		lblSeconds.setBounds(158, 91, 54, 16);
		panel_1.add(lblSeconds);
		
		spinnerSeconds = new JSpinner();
		spinnerSeconds.setBounds(158, 113, 42, 22);
		panel_1.add(spinnerSeconds);
		spinnerSeconds.setModel(new SpinnerNumberModel(0, 0, 59, 1));
		
		Timer timerDate = new Timer(1000, new ActionListener(){
			@Override
			public void actionPerformed(ActionEvent arg0) {
				Calendar calendar = Calendar.getInstance();
				calendar.add(Calendar.DATE, (int)spinnerDays.getValue());
				calendar.add(Calendar.HOUR_OF_DAY, (int)spinnerHour.getValue());
				calendar.add(Calendar.MINUTE, (int)spinnerMinutes.getValue());
				calendar.add(Calendar.SECOND, (int)spinnerSeconds.getValue());
				txtpnYourElectionWill.setText("If you create the election now, Your election will end on:" + calendar.getTime());
			}
			
		});
		timerDate.start();
		
		DefaultListModel actList = new DefaultListModel();
		actList.addElement("Candidate 1");
		actList.addElement("Candidate 2");
		
		JPanel panel_2 = new JPanel();
		panel_2.setBorder(new TitledBorder(null, "Candidates", TitledBorder.LEADING, TitledBorder.TOP, null, null));
		panel_2.setBounds(12, 342, 298, 123);
		contentPane.add(panel_2);
		panel_2.setLayout(null);
		
		JScrollPane scrollPaneCandidates = new JScrollPane();
		scrollPaneCandidates.setBounds(10, 20, 277, 65);
		panel_2.add(scrollPaneCandidates);
		scrollPaneCandidates.setHorizontalScrollBarPolicy(ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
		list = new JList(actList);
		
		scrollPaneCandidates.setViewportView(list);
		
		JButton btnAddCandidate = new JButton("Add Candidate");
		btnAddCandidate.setBounds(12, 85, 136, 25);
		panel_2.add(btnAddCandidate);
		
		JButton btnRemoveCandidate = new JButton("Remove Candidate");
		btnRemoveCandidate.setBounds(136, 85, 150, 25);
		panel_2.add(btnRemoveCandidate);
		
		btnFinish = new JButton("Finish");
		btnFinish.setBounds(493, 427, 97, 25);
		contentPane.add(btnFinish);
		
		JPanel panel_3 = new JPanel();
		panel_3.setBorder(new TitledBorder(null, "Election Description", TitledBorder.LEADING, TitledBorder.TOP, null, null));
		panel_3.setBounds(322, 220, 268, 196);
		contentPane.add(panel_3);
		panel_3.setLayout(null);
		
		JScrollPane scrollPaneDescription = new JScrollPane();
		scrollPaneDescription.setBounds(12, 23, 244, 160);
		JTextArea textArea = new JTextArea();
		textArea.setLineWrap(true);
		textArea.setFont(new Font("Tahoma", Font.PLAIN, 13));
		panel_3.add(scrollPaneDescription);
		scrollPaneDescription.setViewportView(textArea);
		
		btnRemoveCandidate.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				actList.removeElement(list.getSelectedValue());
			}
		});
		
		btnAddCandidate.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				
				AddACandidate add = new AddACandidate();
				add.setVisible(true);
				add.getAddButton().addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent e) {
						if(!add.getTextFieldCandidateAffiliation().isEmpty() && 
						   (!add.getTextFieldCandidateAge().isEmpty() && add.getTextFieldCandidateAge().matches("[0-9]+")) && 
						   (!add.getTextFieldCandidateName().isEmpty() && add.getTextFieldCandidateName().toLowerCase().matches("[a-z]+[ a-z]*")))
						{
							//Store these fields (in the if statement above) in some capacity in the background election system.
							actList.addElement(add.getTextFieldCandidateName());
							add.dispose();
							return;
						}
						JOptionPane.showMessageDialog(add.getOwner(), "One or more fields are invalid.\n"
								+ "Note: Candidate Names cannot contain symbols or .'s"
								+ "\nAge must be a valid number", "Cannot Add the Candidate", JOptionPane.ERROR_MESSAGE);
					}
				});
			}
		});

	}
	public JButton getFinish()
	{
		return btnFinish;
	}
	public boolean canFinish()
	{
		return (list.getModel().getSize() >= 2 &&
				(((comboBoxVote.getModel().getSelectedItem().equals("Full Time Students") ||
			       comboBoxVote.getModel().getSelectedItem().equals("All Students")) &&  textFieldBallotDet.getText().isEmpty()) ||
				 ((comboBoxVote.getModel().getSelectedItem().equals("College Specific") ||
				   comboBoxVote.getModel().getSelectedItem().equals("Class Rank Specific")) &&  !textFieldBallotDet.getText().isEmpty()))
				&& ((int)spinnerDays.getModel().getValue() > 0 || (int)spinnerHour.getModel().getValue() > 0 || 
					(int)spinnerMinutes.getModel().getValue() > 0)
				);
	}
	
	public void setElectionName(String name)
	{
		txtElectionname.setText(name);
	}
}
