import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import java.awt.Toolkit;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class AddACandidate extends JFrame {

	private JPanel contentPane;
	private JTextField textFieldCandidateName;
	private JTextField textFieldCandidateAge;
	private JTextField textFieldCandidateAffiliation;
	private JButton btnAdd;

	/**
	 * Create the Add A Candidate frame.
	 */
	public AddACandidate() {
		setResizable(false);
		setTitle("Add a Candidate");
		setIconImage(Toolkit.getDefaultToolkit().getImage(AddACandidate.class.getResource("/images/Deku_Link_Artwork.png")));
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 307, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblCandidateName = new JLabel("Candidate Name:");
		lblCandidateName.setBounds(12, 13, 114, 16);
		contentPane.add(lblCandidateName);
		
		textFieldCandidateName = new JTextField();
		textFieldCandidateName.setBounds(144, 10, 116, 22);
		contentPane.add(textFieldCandidateName);
		textFieldCandidateName.setColumns(10);
		
		JLabel CandidateAge = new JLabel("Candidate Age:");
		CandidateAge.setBounds(12, 42, 114, 16);
		contentPane.add(CandidateAge);
		
		textFieldCandidateAge = new JTextField();
		textFieldCandidateAge.setColumns(10);
		textFieldCandidateAge.setBounds(144, 39, 116, 22);
		contentPane.add(textFieldCandidateAge);
		
		JLabel lblCandidateAffiliation = new JLabel("Candidate Affiliation:");
		lblCandidateAffiliation.setBounds(12, 71, 127, 16);
		contentPane.add(lblCandidateAffiliation);
		
		textFieldCandidateAffiliation = new JTextField();
		textFieldCandidateAffiliation.setColumns(10);
		textFieldCandidateAffiliation.setBounds(144, 68, 116, 22);
		contentPane.add(textFieldCandidateAffiliation);
		
		btnAdd = new JButton("Add");
		btnAdd.setBounds(180, 215, 97, 25);
		contentPane.add(btnAdd);
	}
	
	public JButton getAddButton()
	{
		return btnAdd;
	}
	
	public String getTextFieldCandidateName()
	{
		return textFieldCandidateName.getText();
	}
	
	public String getTextFieldCandidateAge()
	{
		return textFieldCandidateAge.getText();
	}
	
	public String getTextFieldCandidateAffiliation()
	{
		return textFieldCandidateAffiliation.getText();
	}
}
